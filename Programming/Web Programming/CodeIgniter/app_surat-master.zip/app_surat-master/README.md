# app_surat
App Surat Keluar 
Dibuat dengan : 
1. Codeigniter
2. Bootstrap Admin LTE
3. Javascript
 
Cara menggunakan : 
1. Ganti url lokasi folder CI nya. Buka file config, edit sesuai dengan lokasi tempat kalian menyimpan file2 CI nya.
2. Ganti settingan databse, dan sesuaikan dengan settingan punya kalian



