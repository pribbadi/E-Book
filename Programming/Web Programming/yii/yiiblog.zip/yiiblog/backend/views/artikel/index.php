<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Artikel';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="artikel-index panel panel-info">

    <div class="panel-heading">
        <h4><?= Html::encode($this->title) ?>
        <span class="pull-right">
            <?= Html::a('Tambah Artikel', ['create'], ['class' => 'btn btn-primary btn-sm']) ?>
            <?= Html::a('Kategori', ['/kategori'], ['class' => 'btn btn-danger btn-sm']) ?>
        </span>
        </h4>
    </div>

    <div class="panel-body">
        <?= GridView::widget([
            'dataProvider' => $dataProvider,
            'columns' => [
                ['class' => 'yii\grid\SerialColumn'],
                'judul',
                'idKategori.nama_kategori',
                'jumlah_baca',
                'create_time:date',
                [
                    'class' => 'yii\grid\ActionColumn',
                    'template' => '{update} {delete}'
                ],
            ],
        ]); ?>
    </div>
</div>
