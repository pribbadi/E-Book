<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\Kategori */

$this->title = 'Tambah Kategori';
$this->params['breadcrumbs'][] = ['label' => 'Kategori', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="kategori-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
