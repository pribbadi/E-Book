<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "artikel".
 *
 * @property integer $id_artikel
 * @property string $judul
 * @property string $isi_artikel
 * @property integer $id_kategori
 * @property integer $jumlah_baca
 * @property integer $create_by
 * @property string $create_time
 * @property integer $update_by
 * @property string $update_time
 *
 * @property User $createBy
 * @property User $updateBy
 * @property Kategori $idKategori
 * @property User $createBy0
 * @property User $updateBy0
 * @property Kategori $idKategori0
 * @property Komentar[] $komentars
 */
class Artikel extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'artikel';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['judul', 'isi_artikel', 'id_kategori'], 'required'],
            [['isi_artikel'], 'string'],
            [['id_kategori', 'jumlah_baca', 'create_by', 'update_by'], 'integer'],
            [['judul'], 'string', 'max' => 255],
            [['create_time', 'update_time'], 'string', 'max' => 10]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_artikel' => 'Id Artikel',
            'judul' => 'Judul',
            'isi_artikel' => 'Isi Artikel',
            'id_kategori' => 'Id Kategori',
            'jumlah_baca' => 'Jumlah Baca',
            'create_by' => 'Create By',
            'create_time' => 'Create Time',
            'update_by' => 'Update By',
            'update_time' => 'Update Time',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreateBy()
    {
        return $this->hasOne(User::className(), ['id' => 'create_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdateBy()
    {
        return $this->hasOne(User::className(), ['id' => 'update_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdKategori()
    {
        return $this->hasOne(Kategori::className(), ['id_kategori' => 'id_kategori']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreateBy0()
    {
        return $this->hasOne(User::className(), ['id' => 'create_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdateBy0()
    {
        return $this->hasOne(User::className(), ['id' => 'update_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdKategori0()
    {
        return $this->hasOne(Kategori::className(), ['id_kategori' => 'id_kategori']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getKomentars()
    {
        return $this->hasMany(Komentar::className(), ['id_artikel' => 'id_artikel']);
    }

    public function beforeSave($insert)
    {
        parent::beforeSave($insert);
        if ($this->isNewRecord)
        {
            $this->jumlah_baca = 0;
            $this->create_by = Yii::$app->user->id;
            $this->update_by = Yii::$app->user->id;
            $this->create_time = time();
            $this->update_time = time();
        }
        else
        {
            $this->update_by = Yii::$app->user->id;
            $this->update_time = time();
        }
        return true;
    }

    public static function topArtikel()
    {
        $model  = self::find()
                ->orderBy('jumlah_baca DESC')
                ->limit(10)
                ->all();
        return $model;
    }

    public function topKomentar()
    {
      ///  return self::topArtikel();
        $model  = Artikel::findBySql("SELECT a . * , COUNT( k.id_komentar ) AS jumlah
                        FROM artikel a
                        LEFT JOIN komentar k ON ( k.id_artikel = a.id_artikel ) 
                        GROUP BY a.id_artikel
                        ORDER BY  `jumlah` DESC 
                        LIMIT 0 , 10")       
                ->all();

        return $model;
    }
}
