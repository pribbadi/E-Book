<div class="lesson-description">
    <?php do_action( 'learn_press_begin_course_content_lesson_description' );?>
    <?php the_content(); ?>
    <?php do_action( 'learn_press_end_course_content_lesson_description' );?>
</div>
