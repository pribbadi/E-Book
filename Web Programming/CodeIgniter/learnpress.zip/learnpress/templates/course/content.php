<?php
/**
 * Template for displaying the content of a course
 */

learn_press_prevent_access_directly();
?>
<div class="course-content">
    <?php do_action( 'learn_press_course_content_summary' );?>
</div>
