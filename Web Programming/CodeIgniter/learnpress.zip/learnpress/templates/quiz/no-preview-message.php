<?php
?>
<div class="lp-message error"><?php _e( 'Sorry! You have not permission to view this quiz', 'learn_press' );?></div>