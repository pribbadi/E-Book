<?php


    wp_register_style( "display_css_bootstrap", plugins_url("studypress/css/bootstrap.css",__ROOT_PLUGIN__) );



    wp_register_style( "display_css_bootstrap_sortable", plugins_url("studypress/css/bootstrap-sortable.css",__ROOT_PLUGIN__) );


    wp_enqueue_style('display_css_bootstrap');
    wp_enqueue_style('display_css_bootstrap_sortable');





