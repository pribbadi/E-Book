/**
 * Created by Salim on 05/03/2015.
 */

(function($) {
    $(document).ready(function () {



    })
})(jQuery);



